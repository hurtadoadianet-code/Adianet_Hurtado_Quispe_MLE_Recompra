# Recompra a 60 días

**Adianet Hurtado Quispe · Caso Machine Learning Engineer · Octubre de 2026**

Solución para el ecommerce ficticio The Look. Predice una nueva orden creada
en los 60 días siguientes a la primera orden. Una fila por cliente, variables
disponibles en t0, evaluación temporal con etiquetas maduras y diseño AWS por lotes.

## Ejecución rápida sin credenciales

Python 3.12 o superior. Desde esta carpeta:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
jupyter notebook Adianet_Hurtado_Quispe_Recompra.ipynb
```

Ejecutar todas las celdas en orden. La copia `data/model_base.csv.gz` es la
salida SQL real completa, no datos simulados. Su hash está en `reports/run/metrics.json`.
No incluye nombres, emails, direcciones ni IP. Los IDs se conservan para auditar
unicidad y exportar probabilidades, pero no entran al clasificador.

También puede ejecutarse el pipeline sin notebook:

```powershell
python src/pipeline.py --data data/model_base.csv.gz --output reports/run --cutoff 2025-02-14
```

Las salidas se reemplazan por snapshot. Reejecutar no añade filas ni duplica
predicciones. El pipeline valida claves, madurez, rangos y corte antes de entrenar.
`reports/run/predictions_replay.csv` representa scoring histórico en t0 sobre
clientes recientes al corte del dataset; no es una campaña vigente.

Después de ejecutar el notebook o CLI, los controles adicionales se corren con:

```powershell
python -m unittest discover -s tests -v
```

Cinco pruebas verifican extracción completa, madurez de etiquetas, separación
temporal, rechazo de claves duplicadas/cortes inconsistentes y roundtrip del
pipeline serializado con predicciones idempotentes.

## Reproducir la extracción en BigQuery

1. Usar el proyecto `bussiness-case-tyc`, dataset `bussiness_case_ecommerce`.
2. Ejecutar `sql/00_schema_and_states.sql` para inspeccionar estructura y estados.
3. Ejecutar `sql/01_quality.sql`. Revisar resultados antes de continuar.
4. Ejecutar `sql/02_model_base.sql`, cuyo parámetro `cutoff_ts` usa el primer instante
   del 14/02/2025 UTC, excluyendo el último día incompleto.
5. Descargar la salida completa. La UI limita CSV local a 10 MB: si hace falta,
   agregar al SELECT final `WHERE MOD(f.user_id,2)=0` y luego `=1`, unir y validar
   que no hay duplicados y que el total es 79.634 clientes para este corte.
6. Guardar como `data/model_base.csv.gz`. Para un corte distinto, cambiar SQL y
   configuración Python juntos. Nunca filtrar un CSV antiguo para simular una
   nueva extracción as-of.

No se modificó el dataset de origen ni se desplegaron recursos cloud. Si se desea
persistir el resultado, usar un dataset propio del candidato dentro del proyecto,
con permisos y ubicación correctos. El resultado temporal de BigQuery es suficiente
para reproducir las consultas de esta entrega.

## Decisiones y supuestos

- Primera orden: `ROW_NUMBER` por fecha e ID. Se usa tiempo absoluto UTC.
- Recompra: otra orden con timestamp estrictamente mayor que t0 y menor o igual
  a t0+60 días. Una orden con el mismo timestamp se omite como evento simultáneo.
- Todos los estados cuentan para el objetivo de orden creada. El estado final
  no filtra la primera orden ni se usa como variable. Se incluye sensibilidad
  excluyendo futuras órdenes canceladas. Retornos no borran la creación de una orden.
- Clientes sin 60 días completos: target nulo, fuera de entrenamiento/evaluación.
- Ítems y eventos: solo timestamps <=t0. Se encontraron 78.579 ítems posteriores
  a su orden, por lo que no se usa el ticket completo observado al corte.
- Catálogo estático para categorías. No hay historial del catálogo ni tiempo de
  ingesta; antes de producción se necesita validar disponibilidad y usar snapshots.
- No se usan demografía, PII ni IDs como variables.
- Entrenamiento: labels maduras antes de enero 2024. Validación: enero-junio 2024.
  Test: desde septiembre 2024 hasta el último cliente maduro. Separación de 60 días.
- Ajuste de imputación, escalado y codificación solo en entrenamiento.
- Selección por AP en validación, umbral por F1 de validación. Test reservado
  para reporte. Capacidad comercial ilustrativa del 20%, fijada de antemano.

## Estructura

```text
Adianet_Hurtado_Quispe_Recompra.ipynb  Notebook ejecutado con SQL, resultados y 5 figuras
src/pipeline.py                       Funciones y CLI reproducibles
sql/                                 Consultas de esquema, calidad y base
data/model_base.csv.gz                Base derivada del dataset ficticio
reports/source_quality.json           Evidencia de controles ejecutados
reports/run/                         Métricas, gráficos y predicciones
models/                              Pipeline serializado y metadatos
docs/                                Arquitectura y decisiones de operación
```

Consultar la presentación y la guía de estudio de la carpeta de entregables
para la explicación de resultados. La guía de estudio es material personal de
preparación y no forma parte de los entregables exigidos por el evaluador.

## GitHub y reproducibilidad

El contenido está preparado para revisar y publicar en un repositorio con el
nombre de la candidata. No contiene claves o credenciales. El envío y la publicación
quedan sujetos a revisión de Adianet. Revisar autorización del dataset antes de
publicar la base derivada en un repositorio público; una opción es repositorio
privado con acceso de lectura al evaluador. Las consultas y el notebook permiten
reproducir la extracción con el acceso concedido.

## Fuentes técnicas

- PDF del caso, páginas 1-4. Datos consultados el 25/10/2026.
- https://scikit-learn.org/stable/modules/generated/sklearn.metrics.average_precision_score.html
- https://docs.aws.amazon.com/sagemaker/latest/dg/batch-transform.html
- https://docs.aws.amazon.com/step-functions/latest/dg/using-eventbridge-scheduler.html
- https://docs.cloud.google.com/bigquery/docs/partitioned-tables
- https://docs.cloud.google.com/bigquery/docs/clustered-tables
- https://docs.snowflake.com/en/user-guide/data-load-s3-copy

La arquitectura describe una propuesta, no infraestructura desplegada. Los resultados
en un ecommerce ficticio no prueban impacto ni desempeño sobre clientes reales de Belcorp.
