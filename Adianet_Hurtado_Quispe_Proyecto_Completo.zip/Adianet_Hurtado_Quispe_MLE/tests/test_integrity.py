"""Checks de integridad del resultado SQL y roundtrip de inferencia real."""
from pathlib import Path
import tempfile
import unittest
import joblib
import numpy as np
import pandas as pd
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from src.pipeline import prepare_data,temporal_split,generate_predictions,FEATURES

class IntegrityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.df=prepare_data(ROOT/'data/model_base.csv.gz')

    def test_complete_unique_and_mature(self):
        self.assertEqual(len(self.df),79634)
        self.assertTrue(self.df.user_id.is_unique)
        mature=self.df[self.df.target.notna()]
        self.assertTrue(mature.target.eq(mature.days_to_next_order.between(0,60,inclusive='right').astype(int)).all())
        self.assertEqual(int(self.df.target.isna().sum()),8893)

    def test_temporal_label_maturity_and_feature_exclusions(self):
        train,val,test=temporal_split(self.df)
        self.assertLess((train.first_order_at+pd.Timedelta(days=60)).max(),val.first_order_at.min())
        self.assertLess((val.first_order_at+pd.Timedelta(days=60)).max(),test.first_order_at.min())
        forbidden={'user_id','first_order_id','target','target_non_cancelled','days_to_next_order','first_order_at','cutoff_ts'}
        self.assertFalse(forbidden.intersection(FEATURES))

    def test_reject_inconsistent_cutoff(self):
        with self.assertRaises(ValueError):prepare_data(ROOT/'data/model_base.csv.gz',cutoff='2025-02-13')

    def test_reject_duplicate_client(self):
        sample=pd.read_csv(ROOT/'data/model_base.csv.gz').head(3)
        with tempfile.TemporaryDirectory(dir=ROOT/'reports') as d:
            path=Path(d)/'bad.csv';pd.concat([sample,sample.iloc[[0]]]).to_csv(path,index=False)
            with self.assertRaises(ValueError):prepare_data(path)

    def test_saved_pipeline_and_idempotent_predictions(self):
        artifact=joblib.load(ROOT/'reports/run/model_evaluated.joblib')
        frame=self.df[self.df.target.isna()]
        with tempfile.TemporaryDirectory(dir=ROOT/'reports') as d:
            out=Path(d)/'scores.csv'
            a=generate_predictions(artifact['pipeline'],frame,artifact['model_version'],artifact['threshold'],out)
            first=out.read_bytes()
            b=generate_predictions(artifact['pipeline'],frame,artifact['model_version'],artifact['threshold'],out)
            self.assertEqual(first,out.read_bytes())
            self.assertEqual(len(a),8893)
            self.assertTrue(a.user_id.is_unique)
            expected=pd.read_csv(ROOT/'reports/run/predictions_replay.csv').sort_values('user_id')
            actual=b.sort_values('user_id')
            np.testing.assert_allclose(actual.probability_repurchase_60d,expected.probability_repurchase_60d,rtol=1e-12)

if __name__=='__main__':unittest.main()
