# Cobertura del caso

| Requisito del PDF | Evidencia local |
|---|---|
| Una fila por cliente en SQL | sql/02_model_base.sql y data/model_base.csv.gz |
| Primera compra y recompra a nivel orden en 60 días | CTE first_order y labels, convención documentada |
| Variables disponibles en primera compra | Condiciones de tiempo en basket y activity |
| Cruces sin duplicación | Agregación por user_id antes del SELECT final, validación de unicidad |
| Duplicados, nulos, huérfanos, estados | sql/00_schema_and_states.sql, sql/01_quality.sql y reports/source_quality.json |
| Clientes sin 60 días | target nulo y exclusión de entrenamiento/evaluación |
| Criterio de eficiencia y Snowflake | README, notebook sección 6 y docs/arquitectura_aws.md |
| EDA de tasa, tiempo y segmentos | Figuras 1, 2 y 3 del notebook |
| Funciones, parámetros y validaciones | src/pipeline.py, mostrado en el notebook |
| Reejecución sin duplicar | Snapshot reemplazado y test de idempotencia |
| Modelo contra referencia | DummyClassifier, logística y boosting |
| Separación y métricas justificadas | Notebook sección 4, métricas JSON y figuras 4-5 |
| 3 a 5 gráficos | Cinco figuras en notebook, PNG en reports/run |
| Diseño AWS con fuentes S3 | Diapositiva 8 y docs/arquitectura_aws.md |
| Programación, reentrenamiento y predicción | EventBridge, Step Functions y SageMaker propuestos |
| Almacenamiento y monitoreo | S3 predictions, Processing y CloudWatch propuestos |
| Versionamiento GitHub | Contenido listo para publicar y diseño CI documentado |
| Notebook ejecutado con SQL visible | Adianet_Hurtado_Quispe_Recompra.ipynb |
| Presentación de máximo 10 diapositivas | PPTX y PDF de 10 diapositivas en entregables |
| Nombre en archivo y repositorio | Adianet_Hurtado_Quispe en nombres y README |

Pendiente deliberado para revisión de Adianet: publicación o actualización del
repositorio GitHub y envío de correo. Ninguna de esas acciones se realizó.
El ZIP local permite revisar el proyecto, pero no sustituye el enlace GitHub obligatorio.
